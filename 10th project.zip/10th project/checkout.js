// Load logged-in user details
function loadUserDetails() {
  const user = JSON.parse(localStorage.getItem("loggedInUser"));

  if (!user) {
    alert("Please login first!");
    window.location.href = "index.html"; // go to homepage login
    return;
  }

  document.getElementById("name").value = user.user;   // username
  document.getElementById("mobile").value = user.mobile;
  document.getElementById("pincode").value = user.pincode || "";
  document.getElementById("address").value = user.address || "";

  
}

document.addEventListener("DOMContentLoaded", loadUserDetails);


// Fetch cart from localStorage
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Render cart summary on checkout page
function renderSummary() {
  const summaryItems = document.getElementById("summary-items");
  const summaryTotal = document.getElementById("summary-total");
  summaryItems.innerHTML = "";
  let total = 0;

  cart.forEach((item) => {
    const itemTotal = item.price * (item.qty || 1);
    total += itemTotal;

    summaryItems.innerHTML += `
      <div class="summary-item">
        <span>${item.name} x ${item.qty || 1}</span>
        <span>₹${itemTotal}</span>
      </div>
    `;
  });

  summaryTotal.textContent = total;
}

// Place order function
function placeOrder(e) {
  e.preventDefault();
console.log("Cart at checkout:", cart); 
  if(cart.length === 0) {
    alert("Your cart is empty!");
    return;
  }

  // Get form values
  const name = document.getElementById("name").value;
  const mobile = document.getElementById("mobile").value;
  const address = document.getElementById("address").value;
  const payment = document.getElementById("payment").value;
  const pincode = document.getElementById("pincode").value;

  if(!name || !mobile || !address || !payment || !pincode) {
    alert("Please fill all delivery details!");
    return;
  }
  if (!confirm("Your order will be placed. Proceed?")) {
    return;
  }

  // Create order object
  const order = {
    customer: { name, mobile, address, payment, pincode },
    items: cart,
    total: cart.reduce((sum, i) => sum + (i.price * (i.qty || 1)), 0),
    date: new Date().toLocaleString(),
    status: "Pending"
  };

  // Save order to localStorage (simulate sending to admin)
  let orders = JSON.parse(localStorage.getItem("orders")) || [];
  orders.push(order);
  localStorage.setItem("orders", JSON.stringify(orders));

  // Clear cart
  localStorage.removeItem("cart");
  cart = [];

  

  // Show confirmation message
  document.getElementById("order-msg").textContent =
    "✅ Order placed successfully! Redirecting to products...";

  // Redirect back to products page after 3 seconds
  setTimeout(() => {
    
    window.location.href = "products.html";
  }, 2000);
}

// Initial load
renderSummary();

function cancelOrder(){
  if(confirm("Are you sure you want to cancel and go back to cart?")){
    window.location.href = "products.html";
  }
}