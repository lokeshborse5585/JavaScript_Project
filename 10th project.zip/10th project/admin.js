

let editIndex = null;

/* ================= DUMMY PRODUCTS (AUTO LOAD) ================= */
// localStorage.removeItem("products");
if (!localStorage.getItem("products")) {
 const dummyProducts = [
  /* ===== SEEDS ===== */
  {
    id: 1,
    name: "Wheat Seeds",
    price: 450,
    category: "seeds",
    image: "https://t3.ftcdn.net/jpg/01/60/57/36/360_F_160573622_vXgBJ0sou1iFZbPNCodTkCde4SkC5v8r.jpg"
  },
  {
    id: 2,
    name: "Rice Seeds",
    price: 520,
    category: "seeds",
    image: "https://m.media-amazon.com/images/I/71OKZExBnkL.jpg"
  },
  {
    id: 3,
    name: "Hybrid Tomato Seeds",
    price: 320,
    category: "seeds",
    image: "https://organicbazar.net/cdn/shop/files/Tomatoovalredf1hybridseeds_tomatoseeds_vegetableseeds_hybridseeds_organicbazarseeds_tomato.jpg?v=1758703326&width=1946"
  },
  {
    id: 4,
    name: "Basmati Rice Seeds",
    price: 540,
    category: "seeds",
    image: "https://m.media-amazon.com/images/I/91pxvJeYjhL._AC_UF1000,1000_QL80_.jpg"
  },
  {
    id: 5,
    name: "Onion Seeds",
    price: 280,
    category: "seeds",
    image: "https://m.media-amazon.com/images/I/61228KaCedL._AC_UF1000,1000_QL80_.jpg"
  },

  /* ===== FERTILIZERS ===== */
  {
    id: 6,
    name: "Urea Fertilizer (IFFCO)",
    price: 900,
    category: "fertilizers",
    image: "https://5.imimg.com/data5/ANDROID/Default/2024/7/438879988/NA/SV/XQ/152916664/product-jpeg-500x500.jpg"
  },
  {
    id: 7,
    name: "DAP Fertilizer",
    price: 950,
    category: "fertilizers",
    image: "https://www.kribhco.net/assets/img/product/bharat_dap.jpg"
  },
  {
    id: 8,
    name: "Organic Vermicompost",
    price: 650,
    category: "fertilizers",
    image: "https://m.media-amazon.com/images/I/514okKzdnSL._AC_UF1000,1000_QL80_.jpg"
  },
  {
    id: 9,
    name: "Potash Fertilizer",
    price: 720,
    category: "fertilizers",
    image: "https://5.imimg.com/data5/SELLER/Default/2023/2/ON/ED/KD/182759511/potash.png"
  },

  /* ===== TOOLS ===== */
  {
    id: 10,
    name: "Hoe Tool",
    price: 250,
    category: "tools",
    image: "https://5.imimg.com/data5/SELLER/Default/2022/8/CJ/UN/LL/52580342/hand-hoe-500x500.jpeg"
  },
  {
    id: 11,
    name: "Steel Shovel",
    price: 300,
    category: "tools",
    image: "https://img.freepik.com/premium-photo/shovel-with-handle_93675-28665.jpg"
  },
  {
    id: 12,
    name: "Garden Pruning Shears",
    price: 420,
    category: "tools",
    image: "https://www.ugaoo.com/cdn/shop/articles/814102af2e.jpg?v=1700578798"
  },

  /* ===== MACHINERY ===== */
  {
    id: 13,
    name: "Power Tiller",
    price: 120000,
    category: "machinery",
    image: "https://www.shutterstock.com/image-photo/farmers-cultivate-land-tractor-power-260nw-2195748117.jpg"
  },
  // {
  //   id: 14,
  //   name: "Mahindra Tractor 575",
  //   price: 520000,
  //   category: "machinery",
  //   image: "https://www.shutterstock.com/image-photo/novi-sad-serbia-may-19-260nw-2621199661.jpg"
  // },
  // {
  //   id: 15,
  //   name: "Mini Tractor",
  //   price: 350000,
  //   category: "machinery",
  //   image: "https://m.media-amazon.com/images/I/71iKZJcH0sL.jpg"
  // },

  /* ===== EQUIPMENT ===== */
  {
    id: 16,
    name: "Submersible Water Pump",
    price: 12500,
    category: "equipment",
    image: "https://www.hondaindiapower.com/admin/public/uploads/Products/zmpeYBRiC_Cover.jpg"
  },
  {
    id: 17,
    name: "Drip Irrigation Set",
    price: 9800,
    category: "equipment",
    image: "https://m.media-amazon.com/images/I/71ntSpwK90L._AC_UF1000,1000_QL80_.jpg"
  },
  {
    id: 18,
    name: "Sprayer Pump (Manual)",
    price: 2200,
    category: "equipment",
    image: "https://testing.balwaan.com/uploads/media/2024/manual-sprayer-pump-16-liter-1.webp"
  }
];


  localStorage.setItem("products", JSON.stringify(dummyProducts));
}
function loadDummy(){
  localStorage.removeItem("products");
  location.reload();
}


/* ================= LOAD DATA ================= */
let products = JSON.parse(localStorage.getItem("products")) || [];
let orders = JSON.parse(localStorage.getItem("orders")) || [];

/* ================= DOM ELEMENTS ================= */
const productList = document.getElementById("product-list");
const ordersDiv = document.getElementById("orders");

const nameInput = document.getElementById("name");
const priceInput = document.getElementById("price");
const imageInput = document.getElementById("image");
const categoryInput = document.getElementById("category");

/* ================= ADD PRODUCT ================= */
function addProduct(){
  if(nameInput.value === "" || priceInput.value === ""){
    alert("Please fill all product fields");
    return;
  }

  getImageValue(imageValue => {
    const product = {
      id: Date.now(),
      name: nameInput.value,
      price: Number(priceInput.value),
      image: imageValue,
      category: categoryInput.value
    };

    products.push(product);
    localStorage.setItem("products", JSON.stringify(products));

    nameInput.value = "";
    priceInput.value = "";
    document.getElementById("imageUrl").value = "";
    document.getElementById("imageFile").value = "";

    alert("Product added successfully!");
    renderProducts();
  });
}


function getImageValue(callback){
  const url = document.getElementById("imageUrl").value;
  const file = document.getElementById("imageFile").files[0];

  if(file){
    const reader = new FileReader();
    reader.onload = () => callback(reader.result);
    reader.readAsDataURL(file);
  } else if(url){
    callback(url);
  } else {
    alert("Please provide image URL or upload image");
  }
}


/* ================= RENDER PRODUCTS ================= */
function renderProducts(){
  productList.innerHTML = "";

  if(products.length === 0){
    productList.innerHTML = "<p>No products added.</p>";
    return;
  }

  products.forEach((p, i) => {
    productList.innerHTML += `
      <div class="product-card">
        <img src="${p.image}" alt="${p.name}">
        
        <div class="product-info">
          <h4>${p.name}</h4>
          <p>Category: ${p.category}</p>
          <p>Price: ₹${p.price}</p>
        </div>

        <div class="product-actions">
          <button onclick="editProduct(${i})">✏ Edit</button>
          <button class="delete-btn" onclick="deleteProduct(${i})">🗑 Delete</button>
        </div>
      </div>
    `;
  });
}

/* ================= EDIT PRODUCT (BASIC) ================= */
function editProduct(index){
  editIndex = index;
  const p = products[index];

  document.getElementById("editName").value = p.name;
  document.getElementById("editPrice").value = p.price;
  document.getElementById("editCategory").value = p.category;

  document.getElementById("editImageUrl").value = "";
  document.getElementById("editImageFile").value = "";

  document.getElementById("editModal").style.display = "flex";
}
/* ================= DELETE PRODUCT ================= */
function deleteProduct(index){
  if(confirm("Delete this product?")){
    products.splice(index, 1);
    localStorage.setItem("products", JSON.stringify(products));
    renderProducts();
  }
}

/* ================= RENDER ORDERS ================= */
function renderOrders(){
  ordersDiv.innerHTML = "";

  if(orders.length === 0){
    ordersDiv.innerHTML = "<p>No orders yet.</p>";
    return;
  }

  orders.forEach((order, index) => {

    let buttons = "";

    // ACCEPT & COMPLETE LOGIC
   if(!order.status || order.status === "Pending"){
  buttons += `
    <button onclick="updateStatus(${index}, 'Accepted')">Accept</button>
    <button onclick="updateStatus(${index}, 'Rejected')">Reject</button>
  `;
}
if(order.status === "Accepted"){
  buttons += `<button onclick="updateStatus(${index}, 'Completed')">Complete</button>`;
}
  
  buttons += `<button onclick="deleteOrder(${index})" style="background:red;color:white;">Delete</button>`;
    
   let itemsHTML = "";
    order.items.forEach(item => {
      itemsHTML += `
        <li>
          ${item.name} × ${item.qty || 1}
          — ₹${item.price * (item.qty || 1)}
        </li>
      `;
    });
    ordersDiv.innerHTML += `
      <div class="order-card">
      <div class="order-header">
      
        <h3>🧾 Order #${index + 1}</h3>
         <p>📌 Status</p>
        <p class="status">${order.status}</p>
        
        </div>
        <div class="order-body">
        <b>👤 Customer</b>
        <p>${order.customer.name}</p>

        <b>📞 Mobile</b>
        <p>${order.customer.mobile}</p>

        <b>📍 Address</b>
        <p>${order.customer.address}</p>

        <b>📮 Pincode</b>
        <p>${order.customer.pincode}</p>

         <b>💳 Payment</b>
        <p>${order.customer.payment}</p>
         
         <b>🕒 Date</b>
        <p>${order.date}</p>

         <b>📦 Items</b>
          <ul>${itemsHTML}</ul>

        <b>💰 Total</b>
        <p>₹${order.total}</p>

         
        </div>
<div class="order-footer">

        ${buttons}
</div>
      </div>
    `;
  });
}


function deleteOrder(index){
  if(confirm("Are you sure you want to delete this order?")){
    orders.splice(index, 1);
    localStorage.setItem("orders", JSON.stringify(orders));
    renderOrders();
  }
}

/* ================= UPDATE ORDER STATUS ================= */
function updateStatus(index, status){
  if(!confirm(`Are you sure you want to ${status} this order?`)) return;

  orders[index].status = status;
  localStorage.setItem("orders", JSON.stringify(orders));
  renderOrders();
}
let selectedChatIndex = null;

function renderChatList(){
  const list = document.getElementById("chatList");
  let feedbacks = JSON.parse(localStorage.getItem("feedbacks")) || [];

  list.innerHTML = "";

  if(feedbacks.length === 0){
    list.innerHTML = "<p>No chats yet</p>";
    return;
  }

  feedbacks.forEach((f, i) => {
    list.innerHTML += `
      <div class="chat-user" onclick="openChat(${i})">
        👤 ${f.name} <br>
        📞 ${f.mobile}
        ${f.messages[f.messages.length - 1].time.slice(0, )}
      </div>
    `;
  });
}

function openChat(index){
  selectedChatIndex = index;

  let feedbacks = JSON.parse(localStorage.getItem("feedbacks"));
  let chat = feedbacks[index];

  document.getElementById("chatWindow").style.display = "block";
  document.getElementById("chatUser").innerText =
    `${chat.name} (${chat.mobile})`;

  const msgDiv = document.getElementById("chatMessages");
  msgDiv.innerHTML = "";

  chat.messages.forEach(m => {
    msgDiv.innerHTML += `
      <p><b>${m.from === undefined ? m.sender : m.from}:</b> ${m.text}</p>
    `;
  });
  if(index === undefined) return;

}
function sendAdminReply(){
  const replyText = document.getElementById("adminReply").value;
  if(!replyText) return;

  let feedbacks = JSON.parse(localStorage.getItem("feedbacks"));

  feedbacks[selectedChatIndex].messages.push({
    from: "admin",
    text: replyText,
    time: new Date().toLocaleString()
  });

  localStorage.setItem("feedbacks", JSON.stringify(feedbacks));

  document.getElementById("adminReply").value = "";
  openChat(selectedChatIndex);
}
function sendAdminReply(){
  const replyText = document.getElementById("adminReply").value;
  if(!replyText) return;

  let feedbacks = JSON.parse(localStorage.getItem("feedbacks"));

  feedbacks[selectedChatIndex].messages.push({
    from: "admin",
    text: replyText,
    time: new Date().toLocaleString()
  });

  localStorage.setItem("feedbacks", JSON.stringify(feedbacks));

  document.getElementById("adminReply").value = "";
  openChat(selectedChatIndex);
}
renderChatList();


function deleteChat(){
  if(selectedChatIndex === null) return;

  if(!confirm("Are you sure you want to delete this chat?")) return;

  let feedbacks = JSON.parse(localStorage.getItem("feedbacks")) || [];

  feedbacks.splice(selectedChatIndex, 1);

  localStorage.setItem("feedbacks", JSON.stringify(feedbacks));

  // reset UI
  selectedChatIndex = null;
  document.getElementById("chatWindow").style.display = "none";

  renderChatList();
}

/* ================= INITIAL LOAD ================= */
renderProducts();
renderOrders();

function updateProduct(){
  if(!confirm(" Save changes to this product?")){return}
  if(editIndex === null) return;

  const p = products[editIndex];

  const name = document.getElementById("editName").value.trim();
  const price = document.getElementById("editPrice").value;
  const category = document.getElementById("editCategory").value;
  const url = document.getElementById("editImageUrl").value.trim();
  const file = document.getElementById("editImageFile").files[0];

  if(name) p.name = name;
  if(price) p.price = Number(price);
  if(category) p.category = category;

  if(file){
    const reader = new FileReader();
    reader.onload = () => {
      p.image = reader.result;
      saveAndClose();
    };
    reader.readAsDataURL(file);
  } else if(url){
    p.image = url;
    saveAndClose();
  } else {
    saveAndClose();
  }
}

function saveAndClose(){
  localStorage.setItem("products", JSON.stringify(products));
  renderProducts();
  closeModal();
}

function closeModal(){
  document.getElementById("editModal").style.display = "none";
  editIndex = null;
}