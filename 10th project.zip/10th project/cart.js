let cart = JSON.parse(localStorage.getItem("cart")) || [];

/* ADD TO CART */
function addToCart(name, price){
  let existing = cart.find(item => item.name === name);
  existing ? existing.qty++ : cart.push({ name, price, qty: 1 });
  saveCart(); renderCart();
}

function saveCart(){
  localStorage.setItem("cart", JSON.stringify(cart));
}

function renderCart(){
  const cartItems = document.getElementById("cart-items");
  const total = document.getElementById("total");
  if(!cartItems) return;

  cartItems.innerHTML = "";
  let sum = 0;

  cart.forEach((item, index) => {
    sum += item.price * item.qty;
    cartItems.innerHTML += `
      <div class="cart-row">
        <span>${item.name}</span>
        <span>₹${item.price}</span>
        <div class="qty">
          <button onclick="changeQty(${index}, -1)">−</button>
          <span>${item.qty}</span>
          <button onclick="changeQty(${index}, 1)">+</button>
        </div>
      </div>`;
  });

  total.textContent = sum;
}

function changeQty(index, value){
  cart[index].qty += value;
  if(cart[index].qty <= 0) cart.splice(index,1);
  saveCart(); renderCart();
}

function goToCheckout(){
  if(cart.length === 0) return alert("Your cart is empty!");
  window.location.href = "checkout.html";
}

renderCart();
