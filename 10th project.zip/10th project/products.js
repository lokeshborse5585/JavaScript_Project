let products = JSON.parse(localStorage.getItem("products")) || [];

// ----------------------
// LOGIN CHECK
// ----------------------
function isLoggedIn(){
  return localStorage.getItem("loggedInUser") !== null;
}

// ----------------------
// RENDER PRODUCTS
// ----------------------
function renderProducts(){
  products.forEach(p => {
    const group = document.querySelector(`#${p.category} .product-grid`);
    if(!group) return;

    const loggedIn = isLoggedIn();

    group.innerHTML += `
      <div class="product-card">
        <img src="${p.image}">
        <h4>${p.name}</h4>
        <p>₹${p.price}</p>

        <button onclick="handleAddToCart('${p.name}', ${p.price})">
          ${loggedIn ? "Add to Cart" : "Login to Buy"}
        </button>
      </div>
    `;
  });
}

// ----------------------
// HANDLE ADD TO CART
// ----------------------
function handleAddToCart(name, price){
  if(!localStorage.getItem("loggedInUser")){
    // redirect with flag
    window.location.href = "index.html?login=true";
    return;
  }

  addToCart(name, price);
}


// ----------------------
// HIDE CART PANEL IF NOT LOGGED IN
// ----------------------
document.addEventListener("DOMContentLoaded", () => {
  const cartPanel = document.querySelector(".cart-panel");

  if(cartPanel){
    cartPanel.style.display = isLoggedIn() ? "block" : "none";
  }
});

// ----------------------
renderProducts();
