let products = JSON.parse(localStorage.getItem("products")) || [];

function addProduct() {
  const name = document.getElementById("pName").value;
  const price = document.getElementById("pPrice").value;
  const category = document.getElementById("pCategory").value;
  const image = document.getElementById("pImage").value;

  if (!name || !price || !category || !image) {
    alert("Fill all fields");
    return;
  }

  products.push({
    id: Date.now(),
    name,
    price: Number(price),
    category,
    image
  });

  localStorage.setItem("products", JSON.stringify(products));
  clearForm();
  renderProducts();
}

function deleteProduct(id) {
  products = products.filter(p => p.id !== id);
  localStorage.setItem("products", JSON.stringify(products));
  renderProducts();
}

function renderProducts() {
  const table = document.getElementById("productTable");
  table.innerHTML = "";

  if (products.length === 0) {
    table.innerHTML = `<tr><td colspan="4">No products</td></tr>`;
    return;
  }

  products.forEach(p => {
    table.innerHTML += `
      <tr>
        <td>${p.name}</td>
        <td>₹${p.price}</td>
        <td>${p.category}</td>
        <td>
          <button onclick="deleteProduct(${p.id})">❌ Delete</button>
        </td>
      </tr>
    `;
  });
}

function clearForm() {
  document.getElementById("pName").value = "";
  document.getElementById("pPrice").value = "";
  document.getElementById("pCategory").value = "";
  document.getElementById("pImage").value = "";
}

renderProducts();
