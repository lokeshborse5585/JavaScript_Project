function handleSubmit(e){
  e.preventDefault();

  const user = JSON.parse(localStorage.getItem("loggedInUser"));
  const messageText = document.querySelector("#fbMessage").value.trim();
  const subjectText = document.getElementById("fbSubject").value.trim();
  const guestuser=document.getElementById("fee-name").value.trim();

  if(!messageText){
    alert("Message cannot be empty");
    return;
  }

  let feedbacks = JSON.parse(localStorage.getItem("feedbacks")) || [];

  const feedback = {
    name: user ? user.user : "Guest ["+guestuser+"]",
    mobile: user ? user.mobile : document.getElementById("fbMobile").value,
    messages: [
      {
        from: "User",
        text: messageText,
        time: new Date().toLocaleString()
      }
    ]
  };

  feedbacks.push(feedback);
  localStorage.setItem("feedbacks", JSON.stringify(feedbacks));

  document.getElementById("formMsg").innerText =
    "Your query has been sent successfully ✅";

  // e.target.reset();
  document.querySelector("#fbMessage").value = "";
  document.getElementById("fbSubject").value = "";
  
}
