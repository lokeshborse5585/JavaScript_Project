document.querySelectorAll("#serviceList li").forEach(li=>{
  const img = li.getAttribute("data-img");
  li.style.setProperty("--img", `url(${img})`);
});
