// ---------- MODAL ----------
function openLogin(){
  document.getElementById("authModal").style.display = "flex";
  showLogin();
}

function closeAuth(){
  document.getElementById("authModal").style.display = "none";
}

function showRegister(){
  document.getElementById("loginForm").style.display = "none";
  document.getElementById("registerForm").style.display = "block";
}

function showLogin(){
  document.getElementById("registerForm").style.display = "none";
  document.getElementById("loginForm").style.display = "block";
}

// ---------- REGISTER ----------
function register(){
  const user = regUser.value.trim();
  const pass = regPass.value;
  const confirm = regConfirm.value;
  const mobile = regMobile.value.trim();

  if(!user || !pass || !confirm || !mobile){
    alert("Please fill all fields");
    return;
  }

  if(pass !== confirm){
    alert("Passwords do not match");
    return;
  }

  if(!/^[6-9]\d{9}$/.test(mobile)){
    alert("Enter valid 10-digit mobile number");
    return;
  }
   let users = JSON.parse(localStorage.getItem("users")) || [];
  
     if(users.some(u => u.mobile === mobile)){
    alert("User already exists with this mobile number");
    return;
  }

  users.push({ user, pass, mobile });
  localStorage.setItem("users", JSON.stringify(users));
  alert("Registration successful!");

  showLogin();
}

// ---------- LOGIN ----------
function login(){
  const mobile = loginMobile.value.trim();
  const pass = loginPass.value;

  const users = JSON.parse(localStorage.getItem("users"))||[];
    const foundUser = users.find(
    u => u.mobile === mobile && u.pass === pass
  );
   if(!foundUser){
    alert("Invalid mobile number or password");
    return;
  }



  alert("Login successful!");
  localStorage.setItem("loggedInUser", JSON.stringify(foundUser));
  closeAuth();
  updateNavbar();
  feedbacksAutoFill();   // ✅ NOW IT WILL STAY
}


// ---------- NAVBAR UPDATE ----------
function updateNavbar(){
  const user = JSON.parse(localStorage.getItem("loggedInUser"));

  const loginBtn = document.getElementById("loginBtn");
  const userBox = document.getElementById("userBox");
  const navUsername = document.getElementById("navUsername");
   document.getElementById("myQueriesBtn").style.display = user ? "inline-block" : "none";
  const cartBtn = document.getElementById("cartBtn");

  if(user){
    loginBtn.style.display = "none";
    userBox.style.display = "flex";
    cartBtn.style.display = "inline-block";

    navUsername.innerText = user.user; // 👈 CORRECT FIELD
    if(authModal) authModal.style.display = "none";
  } else {
    loginBtn.style.display = "inline-block";
    userBox.style.display = "none";
    cartBtn.style.display = "none";
  }

  
}

// ---------- LOGOUT ----------
function logout(){
  if( !confirm("Are you sure you want to logout?")) return;
  localStorage.removeItem("loggedInUser");
  updateNavbar();
  // document.getElementById("fee-name").value = "";
  // document.getElementById("fbMobile").value = "";
  // nameField.setAttribute("readonly", false);
    // document.getElementById("fee-name-label").style.top = "-8px";
    // document.getElementById("fee-name-label").style.fontSize = "11px";
    // document.getElementById("fee-name-label").style.color = "#ffffff";
    window.location.reload();
}

// ---------- ON PAGE LOAD ----------
updateNavbar();

function openMyQueries(){
  const user = JSON.parse(localStorage.getItem("loggedInUser"));

  if(!user){
    alert("Please login first");
    return;
  }

  document.getElementById("myQueryModal").style.display = "flex";

  const feedbacks = JSON.parse(localStorage.getItem("feedbacks")) || [];
  const myQueries = feedbacks.filter(f => f.mobile === user.mobile);

  const box = document.getElementById("myQueryList");
  box.innerHTML = "";

  if(myQueries.length === 0){
    box.innerHTML = "<p>No queries yet.</p>";
    return;
  }

  myQueries.forEach(chat => {
    chat.messages.forEach(m => {
      box.innerHTML += `
        <p style="margin: 5px 0; color: #000000; " ><b >${m.from === "User" ? "You" : m.from}:</b> <p style="background-color: #f0f0f0;  border-radius: 5px; padding: 0 0 10px 0; position: relative;"> ${m.text} <span style="font-size: 10px; color: #888888; position: absolute; bottom: 0px; right: 2px;">~${m.time.slice(10, )}</span></p></p>
      `;
    });
  });
}

function closeMyQueries(){
  document.getElementById("myQueryModal").style.display = "none";
}

function feedbacksAutoFill(){
  const user = JSON.parse(localStorage.getItem("loggedInUser"));
  if(!user) return;

  const nameField = document.getElementById("fee-name");
  const mobileField = document.getElementById("fbMobile");
  

  if(nameField){nameField.value = user.user
    nameField.setAttribute("readonly", true);
    document.getElementById("fee-name-label").style.top = "-8px";
    document.getElementById("fee-name-label").style.fontSize = "11px";
    document.getElementById("fee-name-label").style.color = "#ffffff";
  }
  if(mobileField) {mobileField.value = user.mobile
     mobileField.setAttribute("readonly", true);
    document.getElementById("fbMobile-label").style.top = "-8px";
    document.getElementById("fbMobile-label").style.fontSize = "11px";
    document.getElementById("fbMobile-label").style.color = "#ffffff";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  updateNavbar();
  feedbacksAutoFill();
});

function openProfile(){
  const user = JSON.parse(localStorage.getItem("loggedInUser"));
  if(!user) return;

  document.getElementById("profileName").value = user.user;
  document.getElementById("profileMobile").value = user.mobile;
    document.getElementById("profileAddress").value = user.address || "";
  document.getElementById("profilePincode").value = user.pincode || "";
  document.getElementById("profileModal").style.display = "flex";
}

function closeProfile(){
  document.getElementById("profileModal").style.display = "none";
}

function saveProfile(){
  const name = document.getElementById("profileName").value.trim();
  const mobile = document.getElementById("profileMobile").value.trim();
  const address = document.getElementById("profileAddress").value.trim();
  const pincode = document.getElementById("profilePincode").value.trim();
  if(!name || !mobile){
    alert("Name must be required");
    return;
  }

  if(!/^[6-9]\d{9}$/.test(mobile)){
    alert("Enter valid mobile number");
    return;
  }

  let users = JSON.parse(localStorage.getItem("users")) || [];
  let current = JSON.parse(localStorage.getItem("loggedInUser"));

  // update in users list
  if(confirm("Are you sure you want to update your profile?")) {
    
  users = users.map(u => 
    u.mobile === current.mobile ? { ...u, user: name, mobile, address, pincode } : u
  );

  const updatedUser = { ...current, user: name, mobile, address, pincode };

  localStorage.setItem("users", JSON.stringify(users));
  localStorage.setItem("loggedInUser", JSON.stringify(updatedUser));
  updateNavbar();
  feedbacksAutoFill();
   alert("Profile updated successfully");
  }
 

 
  closeProfile();
}



function openOrders() {
  const user = JSON.parse(localStorage.getItem("loggedInUser"));
  if (!user) {
    alert("Please login first");
    return;
  }

  document.getElementById("myOrdersModal").style.display = "flex";

  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  const myOrders = orders.filter(
    o => o.customer.mobile === user.mobile
  );

  const box = document.getElementById("myOrdersList");
  box.innerHTML = "";

  if (myOrders.length === 0) {
    box.innerHTML = "<p>No orders found.</p>";
    return;
  }

  myOrders.forEach(order => {
    box.innerHTML += `
      <div class="order-card">
        <p><b>📅 Date:</b> ${order.date}</p>
        <p><b>📦 Status:</b> ${order.status || "Pending"}</p>
        <p><b>💳 Payment:</b> ${order.customer.payment}</p>

        <div class="order-items">
          ${order.items.map(i => `
            <div>
              🛒 ${i.name} × ${i.qty} — ₹${i.price * i.qty}
            </div>
          `).join("")}
        </div>

        <p><b>💰 Total:</b> ₹${order.total}</p>
        <hr>
      </div>
    `;
  });
}
function closeMyOrders() {
  document.getElementById("myOrdersModal").style.display = "none";
}


function handleUserMenu(action){
   if(action === "orders"){
    openOrders();
  }
  if(action === "profile"){
    openProfile();
  }

  if(action === "logout"){
    logout();
  }

  // reset dropdown back to username
  document.getElementById("userMenu").value = "";
}
